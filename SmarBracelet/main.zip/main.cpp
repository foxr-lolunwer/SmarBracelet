#include <SFML/Graphics.hpp>
#include "S_ui.h"

int main()
{
    ui UI;
    UI.load_init();
    UI.ui_main();
    return 0;
}